from sistema import SistemaBancario

sistema = SistemaBancario()
sistema.menu_principal()